footer-reveal.js
=============

A jQuery plugin for easy implementation of the 'fixed/reveal' footer effect. Demo here: http://iainandrew.github.io/footer-reveal/

## Installation with [Bower](http://bower.io/)
`bower install footer-reveal`
